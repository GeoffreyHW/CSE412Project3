#!/usr/bin/env bash
echo Running Flask
flask run