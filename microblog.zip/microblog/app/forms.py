from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, DecimalField
from wtforms.validators import DataRequired, ValidationError, Email, EqualTo, NumberRange
from app.models import User
from wtforms.fields.html5 import DecimalRangeField

class LoginForm(FlaskForm):
	username = StringField('Username', validators=[DataRequired()])
	password = PasswordField('Password', validators=[DataRequired()])
	remember_me = BooleanField('Remember Me')
	submit = SubmitField('Sign In')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    password2 = PasswordField('Repeat Password', validators=[DataRequired(), EqualTo('password')])
    slider = DecimalRangeField('Year', [NumberRange(min=1, max=100)])
    submit = SubmitField('Register')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user is not None:
            raise ValidationError('Please use a different username.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user is not None:
            raise ValidationError('Please use a different email address.')

class DatabaseQueryForm(FlaskForm):
    movie = StringField('Movie')
    tag = StringField('Tag')
    min_rating = DecimalField('Min_Rating', places=1)
    max_rating = DecimalField('Max_Rating', places=1)
    rating_slider = DecimalRangeField('Rating', [NumberRange(min=1, max=100)])
    submit = SubmitField('Submit')



