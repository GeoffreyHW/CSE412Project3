﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Npgsql;

public partial class _Default : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        List<Int64> movieCount = new List<long>();
        List<string> genereName = new List<string>();
        List<double> averageRate = new List<double>();
        List<string> averageName = new List<string>();
        string connstring = String.Format("Server={0};Port={1};" +
                   "User Id={2};Password={3};Database={4};",
                   "localhost", "5432", "postgres",
                   "1234asdf", "postgres");


        NpgsqlConnection conn = new NpgsqlConnection(connstring);
        conn.Open();

        
        string q = "SELECT g.name AS name, COUNT(g.genreid) AS moviecount FROM movies m, hasagenre h, genres g WHERE m.movieid = h.movieid AND h.genreid = g.genreid GROUP BY g.genreid";
        var cmd = new NpgsqlCommand(q, conn);
        var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            try
            {
                genereName.Add(reader.GetString(0));
                movieCount.Add(reader.GetInt64(1));
            }
            catch
            {

            }

        }
        conn.Close();
        conn.Open();

        Chart1.ChartAreas[0].AxisX.LabelStyle.Interval = 1;

        
        for (int i = 0; i < genereName.Count(); i++)
        {
            Chart1.Series[0].Points.AddXY(genereName[i], movieCount[i]);
        }

        q = "SELECT g.name AS name, AVG(r.rating) AS rating FROM movies m, hasagenre h, genres g, ratings r WHERE m.movieid = h.movieid AND h.genreid = g.genreid AND m.movieid = r.movieid GROUP BY g.genreid";
        var cmd1 = new NpgsqlCommand(q, conn);
        var reader1 = cmd1.ExecuteReader();

        while (reader1.Read())
        {
            
                averageName.Add(reader1.GetString(0));
                averageRate.Add(reader1.GetDouble(1));

        }

        Chart2.ChartAreas[0].AxisX.LabelStyle.Interval = 1;


        for (int i = 0; i < genereName.Count(); i++)
        {
            Chart2.Series[0].Points.AddXY(averageName[i], averageRate[i]);
        }

        conn.Close();

    }

    protected void Chart1_Load(object sender, EventArgs e)
    {
        
    }
}